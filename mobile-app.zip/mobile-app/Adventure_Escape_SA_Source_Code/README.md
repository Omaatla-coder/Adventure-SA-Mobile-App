# Adventure Escape SA — Source Code

This archive contains the source project extracted from the uploaded Adventure Escape Mobile App project.

## Main technology
- React 19
- TypeScript
- Vite
- TanStack React Router / React Start
- Tailwind CSS

## Main application files
- `src/routes/index.tsx` — home / discovery page
- `src/routes/packages.tsx` — package listing
- `src/routes/packages.$slug.tsx` — package details
- `src/routes/activities.tsx` — activities listing
- `src/routes/activities.$slug.tsx` — activity details
- `src/routes/quote.tsx` — quote calculator / enquiry flow
- `src/routes/saved.tsx` — saved experiences
- `src/routes/about.tsx` — about page
- `src/components/` — shared interface components
- `src/data/experiences.ts` — experience and pricing data
- `src/styles.css` — global styles
- `public/photos/` — image assets used by the interface

## Run locally
1. Install Node.js (LTS) and Visual Studio Code.
2. Extract this ZIP.
3. Open the extracted folder in Visual Studio Code.
4. Open Terminal in that folder and run:

   npm install
   npm run dev

5. Open the local address printed in the terminal (normally http://localhost:8080).

## Important
The project may require environment variables or connected services for authentication, database-backed features, and deployment. No private API keys or secrets are included in this source archive. Do not publish secret keys in source control.
