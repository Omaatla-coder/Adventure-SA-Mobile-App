import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { ExperienceCard } from "@/components/cards";
import { activities, packages } from "@/data/experiences";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <Shell>
      <section className="relative min-h-96 bg-navy text-cream">
        <img src="/photos/forest.jpg" alt="Sunlit forest path" className="absolute inset-0 h-full w-full object-cover opacity-60" />
        <div className="absolute inset-0 bg-navy/50" />
        <div className="relative flex min-h-96 flex-col justify-end px-5 pb-6 pt-16">
          <p className="text-xs font-semibold uppercase tracking-widest text-ember">Western Cape · Est. 2024</p>
          <h1 className="mt-2 text-5xl text-cream">Discover. Explore. Escape.</h1>
          <p className="mt-3 text-base text-cream/90">
            Guided outdoor days for families, schools, visitors and teams. See the price before you enquire.
          </p>
          <div className="mt-5 flex gap-2">
            <Link to="/packages" className="rounded-full bg-ember px-4 py-3 text-sm font-semibold text-paper">
              Packages
            </Link>
            <Link to="/quote" className="rounded-full border border-cream/50 px-4 py-3 text-sm font-semibold text-cream">
              Get a quote
            </Link>
          </div>
        </div>
      </section>

      <section className="px-4 py-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="text-3xl text-navy">Packages</h2>
          <Link to="/packages" className="text-sm font-semibold text-forest">See all</Link>
        </div>
        <div className="grid gap-4">
          {packages.slice(0, 2).map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </section>

      <section className="bg-paper px-4 py-6">
        <h2 className="text-3xl text-navy">Add an activity</h2>
        <p className="mt-1 text-sm text-muted">Combine two or more bookings and the discount starts at 5%.</p>
        <div className="mt-4 grid gap-4">
          {activities.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </section>
    </Shell>
  );
}
