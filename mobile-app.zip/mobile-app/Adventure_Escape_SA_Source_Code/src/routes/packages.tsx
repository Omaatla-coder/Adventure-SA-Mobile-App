import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { ExperienceCard } from "@/components/cards";
import { packages } from "@/data/experiences";

export const Route = createFileRoute("/packages")({ component: PackagesPage });

function PackagesPage() {
  return (
    <Shell>
      <div className="px-4 py-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-ember">Guided days</p>
        <h1 className="mt-1 text-4xl text-navy">Packages</h1>
        <p className="mt-2 text-sm text-muted">Four guided days. Each is R1 500 per person.</p>
        <div className="mt-5 grid gap-4">
          {packages.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </div>
    </Shell>
  );
}
