import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Shell } from "@/components/shell";
import { experiences, formatRand, quoteTotals } from "@/data/experiences";
import { useSaved } from "@/lib/saved";

export const Route = createFileRoute("/quote")({ component: QuotePage });

function QuotePage() {
  const { saved } = useSaved();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (saved.length > 0) {
      setSelected((current) => (current.length === 0 ? saved : current));
    }
  }, [saved]);

  const totals = useMemo(() => quoteTotals(selected), [selected]);

  function toggle(slug: string) {
    setSelected((current) =>
      current.includes(slug) ? current.filter((s) => s !== slug) : [...current, slug],
    );
    setShow(false);
  }

  function onQuote() {
    if (!name.trim() || !email.includes("@")) {
      setError("Add your name and a real email so the quote can be sent back.");
      setShow(false);
      return;
    }
    if (selected.length === 0) {
      setError("Choose at least one package or activity.");
      setShow(false);
      return;
    }
    setError("");
    setShow(true);
  }

  return (
    <Shell>
      <div className="px-4 py-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-ember">Calculator</p>
        <h1 className="mt-1 text-4xl text-navy">Instant quote</h1>
        <p className="mt-2 text-sm text-muted">
          One booking is full price. Two is 5% off, three is 10%, four or more is 15%. VAT of 15% is added after the discount.
        </p>

        <form
          className="mt-5 space-y-3"
          onSubmit={(event) => {
            event.preventDefault();
            onQuote();
          }}
        >
          <Field label="Full name" value={name} onChange={setName} type="text" />
          <Field label="Email" value={email} onChange={setEmail} type="email" />
          <Field label="Phone" value={phone} onChange={setPhone} type="tel" />

          <fieldset>
            <legend className="text-sm font-semibold text-navy">What you want</legend>
            <div className="mt-2 grid gap-2">
              {experiences.map((item) => {
                const on = selected.includes(item.slug);
                return (
                  <label
                    key={item.slug}
                    className={`flex min-h-12 cursor-pointer items-center gap-3 rounded-2xl border px-3 py-3 ${on ? "border-forest bg-cream" : "border-line bg-paper"}`}
                  >
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={() => toggle(item.slug)}
                      className="size-5 accent-forest"
                    />
                    <span className="flex-1 text-sm font-medium">{item.name}</span>
                    <span className="text-sm text-forest">{formatRand(item.price)}</span>
                  </label>
                );
              })}
            </div>
          </fieldset>

          {error ? <p className="text-sm font-medium text-ember">{error}</p> : null}

          <button type="submit" className="min-h-12 w-full rounded-full bg-ember text-sm font-semibold text-paper">
            Calculate quote
          </button>
        </form>

        {show ? (
          <section className="mt-5 rounded-card bg-navy p-5 text-cream">
            <p className="text-xs font-semibold uppercase tracking-widest text-ember">Your quote</p>
            <ul className="mt-3 space-y-1 text-sm">
              {totals.items.map((item) => (
                <li key={item.slug} className="flex justify-between gap-3">
                  <span>{item.name}</span>
                  <span>{formatRand(item.price)}</span>
                </li>
              ))}
            </ul>
            <dl className="mt-4 space-y-1 border-t border-cream/20 pt-3 text-sm">
              <Row label="Subtotal" value={formatRand(totals.subtotal)} />
              <Row label={`Discount ${Math.round(totals.rate * 100)}%`} value={`− ${formatRand(totals.discount)}`} />
              <Row label="VAT 15%" value={formatRand(totals.vat)} />
              <div className="flex justify-between pt-2 text-lg font-semibold text-ember">
                <dt>Total</dt>
                <dd>{formatRand(totals.total)}</dd>
              </div>
            </dl>
            <p className="mt-3 text-xs text-cream/70">
              A quote for {name.trim()}, not an invoice. We’ll reply to {email.trim()}.
            </p>
          </section>
        ) : null}
      </div>
    </Shell>
  );
}

function Field({
  label,
  value,
  onChange,
  type,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type: string;
}) {
  return (
    <label className="block text-sm font-semibold text-navy">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 min-h-12 w-full rounded-2xl border border-line bg-paper px-3 font-normal text-ink outline-none focus:border-forest"
      />
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <dt className="text-cream/80">{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}
