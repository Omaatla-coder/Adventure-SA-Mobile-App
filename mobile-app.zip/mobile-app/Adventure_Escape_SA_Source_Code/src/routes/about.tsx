import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <Shell>
      <img src="/photos/hike.jpg" alt="Hikers on a trail" className="h-52 w-full object-cover" />
      <div className="px-5 py-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-ember">The company</p>
        <h1 className="mt-1 text-4xl text-navy">Built for people who would rather be outside.</h1>
        <p className="mt-3 text-sm text-muted">
          Liam Daniels started Adventure Escape SA in 2024 after watching families, schools and visitors bounce between operators just to book one decent day.
        </p>
        <p className="mt-3 text-sm text-muted">
          This app is the mobile companion to the website: the same packages, activities and transparent quote, sized for a phone.
        </p>
        <div className="mt-5 grid gap-3">
          {[
            ["Vision", "The trusted first stop for outdoor days in the Western Cape."],
            ["Mission", "Make discovery, comparison and quoting simple enough that the adventure stays the exciting part."],
            ["Contact", "hello@adventureescapesa.co.za · +27 21 555 0199"],
          ].map(([title, copy]) => (
            <article key={title} className="rounded-card border border-line bg-paper p-4">
              <h2 className="text-2xl text-navy">{title}</h2>
              <p className="mt-1 text-sm text-muted">{copy}</p>
            </article>
          ))}
        </div>
      </div>
    </Shell>
  );
}
