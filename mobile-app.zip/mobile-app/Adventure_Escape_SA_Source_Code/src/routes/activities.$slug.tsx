import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { findExperience, formatRand } from "@/data/experiences";
import { useSaved } from "@/lib/saved";

export const Route = createFileRoute("/activities/$slug")({ component: Detail });

function Detail() {
  const { slug } = Route.useParams();
  const item = findExperience(slug);
  if (!item || item.kind !== "activity") {
    return (
      <Shell>
        <div className="px-5 py-10">
          <h1 className="text-3xl text-navy">Activity not found</h1>
          <Link to="/activities" className="mt-4 inline-block font-semibold text-forest">Back to activities</Link>
        </div>
      </Shell>
    );
  }

  return <Body />;
}

function Body() {
  const { slug } = Route.useParams();
  const item = findExperience(slug)!;
  const { saved, toggle } = useSaved();
  const on = saved.includes(item.slug);

  return (
    <Shell>
      <img src={item.image} alt="" className="h-56 w-full object-cover" />
      <div className="px-5 py-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-forest">{item.place}</p>
        <h1 className="mt-1 text-4xl text-navy">{item.name}</h1>
        <p className="mt-2 text-sm text-muted">{item.duration}</p>
        <p className="mt-4 text-base text-ink">{item.story}</p>
        <h2 className="mt-6 text-2xl text-navy">Includes</h2>
        <ul className="mt-2 space-y-1 text-sm text-muted">
          {item.includes.map((line) => (
            <li key={line}>· {line}</li>
          ))}
        </ul>
        <p className="mt-4 text-sm text-muted"><span className="font-semibold text-navy">Who it’s for. </span>{item.who}</p>
        <p className="mt-5 text-2xl font-semibold text-forest">
          {formatRand(item.price)}
          <span className="block text-xs font-medium text-muted">per person</span>
        </p>
        <div className="mt-4 flex gap-2">
          <button
            type="button"
            onClick={() => toggle(item.slug)}
            className="min-h-12 flex-1 rounded-full border border-navy px-4 text-sm font-semibold text-navy"
          >
            {on ? "Saved" : "Save"}
          </button>
          <Link to="/quote" className="flex min-h-12 flex-1 items-center justify-center rounded-full bg-ember px-4 text-sm font-semibold text-paper">
            Quote this
          </Link>
        </div>
      </div>
    </Shell>
  );
}
