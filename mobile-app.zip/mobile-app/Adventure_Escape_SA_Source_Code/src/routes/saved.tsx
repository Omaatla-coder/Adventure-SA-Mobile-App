import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { ExperienceCard } from "@/components/cards";
import { findExperience } from "@/data/experiences";
import { useSaved } from "@/lib/saved";

export const Route = createFileRoute("/saved")({ component: SavedPage });

function SavedPage() {
  const { saved, ready } = useSaved();
  const items = saved.map((slug) => findExperience(slug)).filter((item) => item != null);

  return (
    <Shell>
      <div className="px-4 py-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-ember">On this phone</p>
        <h1 className="mt-1 text-4xl text-navy">Saved</h1>
        <p className="mt-2 text-sm text-muted">
          Bookmark packages and activities. They stay on this device and load into the quote.
        </p>
        {!ready ? <p className="mt-6 text-sm text-muted">Loading your list…</p> : null}
        {ready && items.length === 0 ? (
          <div className="mt-6 rounded-card bg-paper p-5 ring-1 ring-line">
            <p className="text-navy">Nothing saved yet.</p>
            <p className="mt-1 text-sm text-muted">Tap the bookmark on any card.</p>
            <Link to="/packages" className="mt-4 inline-flex min-h-11 items-center rounded-full bg-navy px-4 text-sm font-semibold text-cream">
              Browse packages
            </Link>
          </div>
        ) : null}
        <div className="mt-5 grid gap-4">
          {items.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
        {items.length > 0 ? (
          <Link to="/quote" className="mt-5 flex min-h-12 items-center justify-center rounded-full bg-ember text-sm font-semibold text-paper">
            Quote these
          </Link>
        ) : null}
      </div>
    </Shell>
  );
}
