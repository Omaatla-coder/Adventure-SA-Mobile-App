import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { ExperienceCard } from "@/components/cards";
import { activities } from "@/data/experiences";

export const Route = createFileRoute("/activities")({ component: ActivitiesPage });

function ActivitiesPage() {
  return (
    <Shell>
      <div className="px-4 py-6">
        <p className="text-xs font-semibold uppercase tracking-widest text-ember">Add-ons</p>
        <h1 className="mt-1 text-4xl text-navy">Activities</h1>
        <p className="mt-2 text-sm text-muted">Ziplining, kayaking or climbing. R750 per person.</p>
        <div className="mt-5 grid gap-4">
          {activities.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </div>
    </Shell>
  );
}
