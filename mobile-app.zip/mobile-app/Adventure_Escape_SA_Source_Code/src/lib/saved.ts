import { useEffect, useState } from "react";

const KEY = "adventure-escape-saved";

export function useSaved() {
  const [saved, setSaved] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as unknown;
        if (Array.isArray(parsed)) setSaved(parsed.filter((s) => typeof s === "string"));
      }
    } catch {
      /* ignore broken storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    localStorage.setItem(KEY, JSON.stringify(saved));
  }, [saved, ready]);

  function toggle(slug: string) {
    setSaved((current) =>
      current.includes(slug) ? current.filter((s) => s !== slug) : [...current, slug],
    );
  }

  return { saved, toggle, ready };
}
