export type Kind = "package" | "activity";

export type Experience = {
  slug: string;
  kind: Kind;
  name: string;
  price: number;
  blurb: string;
  story: string;
  includes: string[];
  who: string;
  image: string;
  duration: string;
  place: string;
};

export const experiences: Experience[] = [
  {
    slug: "ultimate-adventure-day",
    kind: "package",
    name: "Ultimate Adventure Day",
    price: 1500,
    duration: "Full day",
    place: "Hottentots Holland",
    image: "/photos/hike.jpg",
    blurb: "Trail, teamwork and viewpoints for groups who want variety.",
    story:
      "Start under tall pines, move onto open ridges, then finish with a guided challenge that only works if the group talks to each other. Guides set the pace so mixed fitness levels stay together.",
    includes: ["Certified guides", "Trail and ridge walk", "Team challenge", "Safety kit", "Water and a trail snack"],
    who: "Friends, mixed families with older children, and small groups.",
  },
  {
    slug: "family-explorer",
    kind: "package",
    name: "Family Explorer",
    price: 1500,
    duration: "Half to full day",
    place: "Constantia & Helderberg",
    image: "/photos/family.jpg",
    blurb: "Slow enough for children, interesting enough that adults stay present.",
    story:
      "Short forest sections, a stream stop, and a summit only if the group wants it. Guides keep the day playful without turning it into a race.",
    includes: ["Family-trained guides", "Nature scavenger brief", "Flexible distance", "Safety kit", "Water"],
    who: "Families, school groups and first-time hikers.",
  },
  {
    slug: "mountain-adventure",
    kind: "package",
    name: "Mountain Adventure",
    price: 1500,
    duration: "Full day",
    place: "Cape Fold Mountains",
    image: "/photos/mountain.jpg",
    blurb: "A proper mountain day: steady ascent, fynbos, and a view that earns the climb.",
    story:
      "You walk into sandstone and wind. The route is chosen for the weather that morning, with a real summit option and a shorter ridge if the group needs it.",
    includes: ["Mountain guide", "Route choice on the day", "Navigation brief", "Emergency kit", "Water"],
    who: "Adults and teens comfortable with a full day on foot.",
  },
  {
    slug: "corporate-team-challenge",
    kind: "package",
    name: "Corporate Team Challenge",
    price: 1500,
    duration: "Half day",
    place: "Peninsula trails",
    image: "/photos/team.jpg",
    blurb: "Outdoor problems that only get solved if people actually listen.",
    story:
      "No trust-fall theatre. Stations on the trail ask a team to plan, carry, and decide under a clock, then debrief in the shade before heading back.",
    includes: ["Facilitator and safety guide", "Timed stations", "Debrief", "Kit", "Water"],
    who: "Companies, departments and leadership groups.",
  },
  {
    slug: "ziplining",
    kind: "activity",
    name: "Ziplining",
    price: 750,
    duration: "2 hours",
    place: "Constantia Nek",
    image: "/photos/canyon.jpg",
    blurb: "Cables over a green valley, with a walk between platforms.",
    story:
      "You ride several lines above fynbos and forest. Briefing is unhurried. Speed is controlled. The view is the point.",
    includes: ["Harness and helmet", "Two guides", "Safety briefing", "Photos on request"],
    who: "Anyone within the weight limit who is fine with height.",
  },
  {
    slug: "kayaking",
    kind: "activity",
    name: "Kayaking",
    price: 750,
    duration: "2 hours",
    place: "Western Cape rivers",
    image: "/photos/kayak.jpg",
    blurb: "A calm paddle with instruction, not a white-water test.",
    story:
      "You launch from a quiet bank, learn a stroke that actually works, and follow the guide through reeds and open water.",
    includes: ["Kayak and paddle", "Life jacket", "Guide", "Dry bag for a phone"],
    who: "Beginners and anyone who can sit and paddle.",
  },
  {
    slug: "rock-climbing",
    kind: "activity",
    name: "Rock Climbing",
    price: 750,
    duration: "2 hours",
    place: "Peninsula crags",
    image: "/photos/climb.jpg",
    blurb: "A first session on real rock, with a rope that is already set.",
    story:
      "You learn how the harness works, then climb short lines with a guide on the ground. Height is optional. The rock is the classroom.",
    includes: ["Harness and helmet", "Guide", "Top-rope lines", "Safety brief"],
    who: "Beginners and anyone curious about height.",
  },
];

export const packages = experiences.filter((e) => e.kind === "package");
export const activities = experiences.filter((e) => e.kind === "activity");

export function findExperience(slug: string) {
  return experiences.find((e) => e.slug === slug);
}

export function formatRand(n: number) {
  const whole = Math.round(n);
  const body = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `R${body}`;
}

export function discountRate(count: number) {
  if (count >= 4) return 0.15;
  if (count === 3) return 0.1;
  if (count === 2) return 0.05;
  return 0;
}

export function quoteTotals(slugs: string[]) {
  const items = slugs
    .map((slug) => findExperience(slug))
    .filter((item): item is Experience => Boolean(item));
  const subtotal = items.reduce((sum, item) => sum + item.price, 0);
  const rate = discountRate(items.length);
  const discount = Math.round(subtotal * rate);
  const after = subtotal - discount;
  const vat = Math.round(after * 0.15);
  return { items, subtotal, rate, discount, vat, total: after + vat };
}
