import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Bookmark, Calculator, Compass, Mountain, Trees } from "lucide-react";

const tabs = [
  { to: "/", label: "Discover", icon: Compass },
  { to: "/packages", label: "Packages", icon: Mountain },
  { to: "/activities", label: "Activities", icon: Trees },
  { to: "/quote", label: "Quote", icon: Calculator },
  { to: "/saved", label: "Saved", icon: Bookmark },
] as const;

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2">
      <svg viewBox="0 0 64 64" className="size-9 shrink-0" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill={light ? "#FFF6DC" : "#0A2540"} />
        <path d="M10 44 L22 24 L32 34 L43 18 L54 44 Z" fill={light ? "#0A2540" : "#FFF6DC"} />
        <path d="M10 44 L24 30 L32 38 L42 26 L54 44 Z" fill="#1F6B2C" />
        <circle cx="44" cy="16" r="6" fill="#E85D04" />
        <path d="M22 50 Q32 42 42 50" stroke="#E85D04" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </svg>
      <span className={`font-display text-base leading-none ${light ? "text-cream" : "text-navy"}`}>
        Adventure Escape
        <span className="mt-0.5 block text-xs font-sans tracking-wide text-ember">South Africa</span>
      </span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-stage md:flex md:items-center md:justify-center md:py-6">
      <div className="relative mx-auto flex min-h-dvh w-full max-w-md flex-col bg-cream md:h-[min(900px,94dvh)] md:min-h-0 md:overflow-hidden md:rounded-device md:shadow-2xl md:ring-8 md:ring-navy">
        <header className="sticky top-0 z-30 flex items-center justify-between bg-navy px-4 py-3 text-cream">
          <Logo light />
          <Link to="/about" className="rounded-full px-3 py-2 text-sm font-semibold text-cream/90">
            About
          </Link>
        </header>
        <main className="flex-1 overflow-y-auto pb-24">{children}</main>
        <nav className="absolute inset-x-0 bottom-0 z-30 border-t border-line bg-paper/95 backdrop-blur">
          <ul className="grid grid-cols-5">
            {tabs.map((tab) => {
              const active = tab.to === "/" ? path === "/" : path.startsWith(tab.to);
              const Icon = tab.icon;
              return (
                <li key={tab.to}>
                  <Link
                    to={tab.to}
                    className={`flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-semibold ${active ? "text-ember" : "text-muted"}`}
                  >
                    <Icon className="size-5" strokeWidth={active ? 2.4 : 1.8} />
                    {tab.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </div>
  );
}
