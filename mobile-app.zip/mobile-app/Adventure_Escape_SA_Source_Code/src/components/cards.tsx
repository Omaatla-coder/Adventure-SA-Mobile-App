import { Link } from "@tanstack/react-router";
import { Bookmark } from "lucide-react";
import { formatRand, type Experience } from "@/data/experiences";
import { useSaved } from "@/lib/saved";

export function ExperienceCard({ item }: { item: Experience }) {
  const href = item.kind === "package" ? "/packages/$slug" : "/activities/$slug";
  const { saved, toggle } = useSaved();
  const on = saved.includes(item.slug);

  return (
    <article className="overflow-hidden rounded-card bg-paper shadow-sm ring-1 ring-line">
      <div className="relative">
        <img src={item.image} alt="" className="h-40 w-full object-cover" />
        <button
          type="button"
          aria-pressed={on}
          aria-label={on ? `Remove ${item.name}` : `Save ${item.name}`}
          onClick={() => toggle(item.slug)}
          className={`absolute right-3 top-3 grid size-11 place-items-center rounded-full ${on ? "bg-ember text-paper" : "bg-paper/90 text-navy"}`}
        >
          <Bookmark className="size-5" fill={on ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="p-4">
        <p className="text-xs font-semibold uppercase tracking-widest text-forest">{item.place}</p>
        <h3 className="mt-1 text-2xl text-navy">{item.name}</h3>
        <p className="mt-1 text-sm text-muted">{item.blurb}</p>
        <div className="mt-4 flex items-end justify-between gap-3">
          <p className="text-lg font-semibold text-forest">
            {formatRand(item.price)}
            <span className="block text-xs font-medium text-muted">per person</span>
          </p>
          <Link
            to={href}
            params={{ slug: item.slug }}
            className="rounded-full bg-navy px-4 py-2 text-sm font-semibold text-cream"
          >
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}
